$(document).ready(function () {
$("table table td:contains('NIL')").closest("tr").hide();
});
