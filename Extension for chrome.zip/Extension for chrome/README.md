#VIT Academics Enhancement Suite
Enhance your browsing experience on VIT Academics Student Login.

## TODOS
1.Change Main.js file and update functionality with jquery

~~2.Move files to corresponding folders~~

3.Remove css bugs in coursepage

4 .Remove moving spotlight and replace it with a static spotlight which shows all events.

5 .Update the functionality of VES to ~~online payment~~ and Registration , ADD/DROP .

6 .Show Faculty messages on top of the message frame when page loads instead of marquee from bottom.
