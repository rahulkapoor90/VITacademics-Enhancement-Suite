document.getElementById("tree23ec0_0_1").style.display="none";
document.getElementById("tree23ec0_0_3").style.display="none";
document.getElementById("tree23ec0_0_6").style.display="none";
document.getElementById("tree23ec0_0_9").style.display="none";
document.getElementById("tree23ec0_0_11").style.display="none";
//document.getElementById("tree23ec0_0_2_ico").src = "http://gujaratsamachar.com/pages/images/bullet2_on.png";
for(var i=2;i<=36;i++){
	document.getElementById('tree23ec0_0_' + i + '_ico').src =  "http://www.sunflowerinternational.com/images/bullet.png";
}
for(var j=10;j<=24;j++){
document.getElementById('tree23ec0_0_' + j + '_flagImg').src = "http://img.misco.eu/resources/images/Modules/ContentManagement/1210/2014/landing-pages/no_result_page/icon_plus.png";
}