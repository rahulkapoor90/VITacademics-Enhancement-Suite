//document.getElementById("tree23ec0_0_2_ico").src = "http://gujaratsamachar.com/pages/images/bullet2_on.png";
for(var i=2;i<=36;i++){
	document.getElementById('tree23ec0_0_' + i + '_ico').src =  "https://i.imgur.com/nAnJHcz.png";
}
for(var j=10;j<=24;j++){
document.getElementById('tree23ec0_0_' + j + '_flagImg').src = "https://i.imgur.com/YFcV4bO.png";
}