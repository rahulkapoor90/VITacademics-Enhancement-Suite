//document.getElementById("tree23ec0_0_2_ico").src = "http://gujaratsamachar.com/pages/images/bullet2_on.png";

// dotIcon and arrowIcons Nodes
var dotIcons = document.querySelectorAll('[id^="tree23ec0_0_"][id$="_ico"]');
var arrowIcons = document.querySelectorAll('[id^="tree23ec0_0_"][id$="_flagImg"]');

for(var i = 0;i< dotIcons.length;i++){
	dotIcons[i].src =  "https://res.cloudinary.com/dadfowug4/image/upload/v1479314802/nAnJHcz_kt2did.png";
}
for(var j = 0;j < arrowIcons.length;j++){
	arrowIcons[i].src = "https://res.cloudinary.com/dadfowug4/image/upload/v1479314802/YFcV4bO_oppp1h.png";
}