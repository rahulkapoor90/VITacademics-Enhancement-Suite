//document.getElementById("tree23ec0_0_2_ico").src = "http://gujaratsamachar.com/pages/images/bullet2_on.png";
for(var i=2;i<=36;i++){
	document.getElementById('tree23ec0_0_' + i + '_ico').src =  "https://res.cloudinary.com/dadfowug4/image/upload/v1479314802/nAnJHcz_kt2did.png";
}
for(var j=10;j<=24;j++){
document.getElementById('tree23ec0_0_' + j + '_flagImg').src = "https://res.cloudinary.com/dadfowug4/image/upload/v1479314802/YFcV4bO_oppp1h.png";
}